package com.example.doppelganger;

import android.content.Intent;
import android.os.Bundle;  // Import Bundle
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {  // Add Bundle parameter
        super.onCreate(savedInstanceState);  // Call super.onCreate()
        setContentView(R.layout.activity_main);  // Set the content view to the layout file (e.g., activity_main.xml)

        // Find the button and set the click listener
        Button button2 = findViewById(R.id.button);  // Make sure button ID matches the one in your XML layout
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an intent to move from MainActivity to GameActivity
                Intent intent = new Intent(MainActivity.this, GameLevel2.class);
                intent.putExtra("MAX_MISTAKES", 5);
                intent.putExtra("TOTAL_PAIRS", 6);
                startActivity(intent);


            }
        });
    }
}
