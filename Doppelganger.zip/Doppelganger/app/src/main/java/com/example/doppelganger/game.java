package com.example.doppelganger;

import android.os.*;
import android.widget.*;
import android.view.*;

public class game {


    public void startGame() {

        final Handler handler = new Handler(Looper.getMainLooper());

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Code to execute after 3 seconds (3000ms)

                ImageView imageView2 = findViewById(R.id.imageView2);

                imageView2.setImageResource(R.drawable.screenshot_1446_02_19_at_6_08_43pm);

            }
        }, 3000);  // Delay of 3 seconds (3000 milliseconds)
    }
}
