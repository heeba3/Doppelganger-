package com.example.doppelganger;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class game extends AppCompatActivity {

    ImageView firstCard, secondCard;
    boolean isFirstCardFlipped = false;
    int mistakes = 0;  // Track mistakes
    int matches = 0;   // Track matches
    final int maxMistakes = 3;  // Max mistakes allowed
    final int totalPairs = 3;   // Total pairs of cards

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_); // Set the layout

        startGame(this);
    }

    public void startGame(Activity activity) {
        final Handler handler = new Handler(Looper.getMainLooper());

        // Find image views
        ImageView imageViewcup = activity.findViewById(R.id.cupcake);
        ImageView imageViewice = activity.findViewById(R.id.icecream);
        ImageView imageViewstr = activity.findViewById(R.id.strwaberrycake);
        ImageView imageViewcup2 = activity.findViewById(R.id.cupcake2);
        ImageView imageViewice2 = activity.findViewById(R.id.icecream2);
        ImageView imageViewstr2 = activity.findViewById(R.id.strwaberrycake2);

        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Flip all cards back after showing initially
                imageViewcup.setImageResource(R.drawable.card);
                imageViewice.setImageResource(R.drawable.card);
                imageViewstr.setImageResource(R.drawable.card);
                imageViewcup2.setImageResource(R.drawable.card);
                imageViewice2.setImageResource(R.drawable.card);
                imageViewstr2.setImageResource(R.drawable.card);

                // Set onClickListeners for each card
                setOnClickListener(imageViewcup, R.drawable.cupcake);
                setOnClickListener(imageViewcup2, R.drawable.cupcake);
                setOnClickListener(imageViewice, R.drawable.icecream);
                setOnClickListener(imageViewice2, R.drawable.icecream);
                setOnClickListener(imageViewstr, R.drawable.strwaberrycake);
                setOnClickListener(imageViewstr2, R.drawable.strwaberrycake);
            }
        }, 2000);  // Delay for initial display
    }

    private void setOnClickListener(final ImageView card, final int drawableId) {
        card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle first and second card flips
                if (!isFirstCardFlipped) {
                    firstCard = card;
                    card.setImageResource(drawableId);
                    isFirstCardFlipped = true;
                } else if (firstCard != card) {
                    secondCard = card;
                    card.setImageResource(drawableId);
                    isFirstCardFlipped = false;

                    // Check if the two cards match
                    if (firstCard.getDrawable().getConstantState().equals(secondCard.getDrawable().getConstantState())) {
                        firstCard.setEnabled(false);
                        secondCard.setEnabled(false);
                        matches++;

                        // Check if all pairs are matched
                        if (matches == totalPairs) {
                            showMessageAndEndGame("You won!");
                        }
                    } else {
                        // Cards don't match, increment mistakes
                        mistakes++;
                        if (mistakes >= maxMistakes) {
                            showMessageAndEndGame("You lost! Too many mistakes.");
                        } else {
                            Handler handler = new Handler(Looper.getMainLooper());
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    firstCard.setImageResource(R.drawable.card);
                                    secondCard.setImageResource(R.drawable.card);
                                }
                            }, 1000); // Delay to flip cards back
                        }
                    }
                }
            }
        });
    }

    // Show a dialog message (win/lose) and return to the main activity
    private void showMessageAndEndGame(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(game.this);
        builder.setMessage(message)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Return to main activity after clicking OK
                        Intent intent = new Intent(game.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                });

        AlertDialog alert = builder.create();
        alert.show();
    }
}
