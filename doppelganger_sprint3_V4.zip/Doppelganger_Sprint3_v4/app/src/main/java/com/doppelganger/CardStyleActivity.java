package com.doppelganger;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.concurrent.atomic.AtomicBoolean;

public class CardStyleActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;

    private ImageView cardStyle1, cardStyle2, cardStyle3;
    private Button saveSelectionButton, adminEditButton;
    public static int flag;
    private int myCoins;
    private boolean style1Bought = false;
    private boolean style3Bought = false;

    private String loggedInUserEmail;
    private String loggedInUserPassword;

    private StorageReference storageReference;
    private DatabaseReference databaseReference;

    private static final String ADMIN_EMAIL = "admin@gmail.com";
    private static final String ADMIN_PASSWORD = "1111";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_style);
        cardStyle1 = findViewById(R.id.cardStyle1);
        cardStyle2 = findViewById(R.id.cardStyle2);
        cardStyle3 = findViewById(R.id.cardStyle3);

        //Coins coins= new Coins();
        //myCoins= coins.calcCoins();
        myCoins=50;

        TextView coinsWallet = findViewById(R.id.coins);
        coinsWallet.setText(String.valueOf(myCoins));

        Button button= findViewById(R.id.Return);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start LevelSelectionActivity
                Intent intent = new Intent(CardStyleActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // Initialize views
//        cardStyle1 = findViewById(R.id.cardStyle1);
//        cardStyle2 = findViewById(R.id.cardStyle2);
//        cardStyle3 = findViewById(R.id.cardStyle3);
//        saveSelectionButton = findViewById(R.id.saveSelectionButton);
//        adminEditButton = findViewById(R.id.adminEditButton);
//
//        storageReference = FirebaseStorage.getInstance().getReference("card_styles");
//        databaseReference = FirebaseDatabase.getInstance().getReference("card_styles");
//
//        // Get user credentials
//        loggedInUserEmail = getIntent().getStringExtra("email");
//        loggedInUserPassword = getIntent().getStringExtra("password");
//
//        // Load card styles
//        loadCardStyles();
//
//        // Handle card style save
//        saveSelectionButton.setOnClickListener(v -> {
//            Toast.makeText(this, "Card style saved. Starting game...", Toast.LENGTH_SHORT).show();
//            Intent intent = new Intent(CardStyleActivity.this, LevelSelection.class);
//            startActivity(intent);
//        });
//
//        // Admin upload functionality
//        if (isAdmin()) {
//            adminEditButton.setVisibility(View.VISIBLE);
//            adminEditButton.setOnClickListener(v -> openFileChooser());
//        } else {
//            adminEditButton.setVisibility(View.GONE);
//        }

//        setupCardSelection();
      }

    public void cardStyle1(View view){
        TextView coinsWallet = findViewById(R.id.coins);
        if (style1Bought) {
            Toast.makeText(this, "This card Style is now set.", Toast.LENGTH_SHORT).show();
            return;
        }

        if(myCoins <15){
            Toast.makeText(this, "You don't have enough coins.", Toast.LENGTH_SHORT).show();
        }
        else if(myCoins>=15){
            style1Bought= true;
            myCoins=myCoins-15;
            flag=1;
            Toast.makeText(this, "Purchased!", Toast.LENGTH_SHORT).show();
            coinsWallet.setText(String.valueOf(myCoins));
        }
    }
    public void cardStyle2(View view){
        flag=2;
        Toast.makeText(this, "This card Style is now set.", Toast.LENGTH_SHORT).show();
    }
    public void cardStyle3(View view){
        TextView coinsWallet = findViewById(R.id.coins);
        if (style3Bought) {
            Toast.makeText(this, "This card Style is now set.", Toast.LENGTH_SHORT).show();
            return;
        }

        if(myCoins <25){
            Toast.makeText(this, "You don't have enough coins.", Toast.LENGTH_SHORT).show();
        }
        else if(myCoins>=25){
            myCoins=myCoins-25;
            style3Bought=true;
            Toast.makeText(this, "Purchased!", Toast.LENGTH_SHORT).show();
            coinsWallet.setText(String.valueOf(myCoins));
            flag=3;
        }
    }

//    private void selectedStyle(){
//
//        cardStyle1 = findViewById(R.id.cardStyle1);
//        cardStyle2 = findViewById(R.id.cardStyle2);
//        cardStyle3 = findViewById(R.id.cardStyle3);
//        Coins coins= new Coins();
//        myCoins= coins.calcCoins();
//        myCoins= 0;
//        TextView coinsWallet = findViewById(R.id.coins);
//        coinsWallet.setText(String.valueOf(myCoins));
//
//        cardStyle1.setOnClickListener(v -> {
//            // for 15 coins
//             if(myCoins <15){
//                 Toast.makeText(this, "You don't have enough coins.", Toast.LENGTH_SHORT).show();
//             }
//             else if(myCoins>=15){
//                 myCoins=myCoins-15;
//                 flag=1;
//             }
//        });
//        cardStyle2.setOnClickListener(v -> {
//            // for 0 coins
//            flag=2;
//
//        });
//        cardStyle3.setOnClickListener(v -> {
//            // for 25 coins
//            if(myCoins <25){
//                Toast.makeText(this, "You don't have enough coins.", Toast.LENGTH_SHORT).show();
//            }
//            else if(myCoins>=25){
//                myCoins=myCoins-25;
//                flag=3;
//            }
//
//        });
//
//        coinsWallet.setText(myCoins);
//
//    }
//
//
//    private boolean isAdmin() {
//        return ADMIN_EMAIL.equals(loggedInUserEmail) && ADMIN_PASSWORD.equals(loggedInUserPassword);
//    }
//
//    private void openFileChooser() {
//        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
//        intent.setType("image/*");
//        startActivityForResult(Intent.createChooser(intent, "Select Card Style"), PICK_IMAGE_REQUEST);
//    }
//
//    @Override
//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//
//        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
//            Uri imageUri = data.getData();
//            uploadImageToFirebase(imageUri);
//        }
//    }
//
//    private void uploadImageToFirebase(Uri imageUri) {
//        if (imageUri != null) {
//            String fileName = System.currentTimeMillis() + ".jpg";
//            StorageReference fileReference = storageReference.child(fileName);
//
//            fileReference.putFile(imageUri)
//                    .addOnSuccessListener(taskSnapshot -> fileReference.getDownloadUrl().addOnSuccessListener(uri -> {
//                        databaseReference.child("style1").setValue(uri.toString());
//                        Toast.makeText(CardStyleActivity.this, "Card style updated successfully!", Toast.LENGTH_SHORT).show();
//                        loadCardStyles();
//                    }))
//                    .addOnFailureListener(e -> Toast.makeText(CardStyleActivity.this, "Upload failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
//        }
//    }
//
//    private void loadCardStyles() {
//        databaseReference.child("style1").get().addOnSuccessListener(snapshot -> {
//            String url = snapshot.getValue(String.class);
//            if (url != null && !url.isEmpty()) {
//                Glide.with(this).load(url).into(cardStyle1);
//            }
//        });
//
//        databaseReference.child("style2").get().addOnSuccessListener(snapshot -> {
//            String url = snapshot.getValue(String.class);
//            if (url != null && !url.isEmpty()) {
//                Glide.with(this).load(url).into(cardStyle2);
//            }
//        });
//
//        databaseReference.child("style3").get().addOnSuccessListener(snapshot -> {
//            String url = snapshot.getValue(String.class);
//            if (url != null && !url.isEmpty()) {
//                Glide.with(this).load(url).into(cardStyle3);
//            }
//        });
//    }
//
//    private void setupCardSelection() {
//
//        cardStyle1.setOnClickListener(v -> {
//            Toast.makeText(this, "Card style 1 selected!", Toast.LENGTH_SHORT).show();
//            saveSelectedCardStyle("style1");
//        });
//
//        cardStyle2.setOnClickListener(v -> {
//            Toast.makeText(this, "Card style 2 selected!", Toast.LENGTH_SHORT).show();
//            saveSelectedCardStyle("style2");
//        });
//
//        cardStyle3.setOnClickListener(v -> {
//            Toast.makeText(this, "Card style 3 selected!", Toast.LENGTH_SHORT).show();
//            saveSelectedCardStyle("style3");
//        });
//    }
//
//    private void saveSelectedCardStyle(String styleKey) {
//        databaseReference.child("selectedStyle").setValue(styleKey);
//    }
  }


