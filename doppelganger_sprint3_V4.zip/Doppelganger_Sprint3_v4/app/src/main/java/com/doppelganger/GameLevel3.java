package com.doppelganger;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;

public class GameLevel3 extends GameBase {

    public int level1Coins = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_level_3);

        flipCards();
    }

    private void flipCards() {
        // Find image views
        Handler handler = new Handler(Looper.getMainLooper());
        ImageView imageViewcup = findViewById(R.id.cupcake);
        ImageView imageViewice = findViewById(R.id.icecream);
        ImageView imageViewstr = findViewById(R.id.strwaberrycake);
        ImageView imageViewcup2 = findViewById(R.id.cupcake2);
        ImageView imageViewice2 = findViewById(R.id.icecream2);
        ImageView imageViewstr2 = findViewById(R.id.strwaberrycake2);

        ImageView img7 = findViewById(R.id.cherry);
        ImageView img8 = findViewById(R.id.cherry2);
        ImageView img9 = findViewById(R.id.apple);
        ImageView img10 = findViewById(R.id.apple2);
        ImageView img11 = findViewById(R.id.birthdaycake);
        ImageView img12 = findViewById(R.id.birthdaycake2);

        ImageView img13 = findViewById(R.id.avocado);
        ImageView img14 = findViewById(R.id.avocado2);
        ImageView img15 = findViewById(R.id.donut);
        ImageView img16 = findViewById(R.id.donut2);
        ImageView img17 = findViewById(R.id.pink_cake);
        ImageView img18 = findViewById(R.id.pink_cake2);

        ImageView img19 = findViewById(R.id.berry);
        ImageView img20 = findViewById(R.id.berry2);
        ImageView img21 = findViewById(R.id.choclate_cake);
        ImageView img22 = findViewById(R.id.choclate_cake2);
        ImageView img23 = findViewById(R.id.birthday_cupcake);
        ImageView img24 = findViewById(R.id.birthday_cupcake2);

        handler.postDelayed(() -> {
            // Flip all cards back after showing initially
            if (CardStyleActivity.flag == 1) {
                flipToCard1(imageViewcup, imageViewice, imageViewstr, imageViewcup2, imageViewice2, imageViewstr2, img7, img8, img9, img10, img11, img12, img13, img14, img15, img16, img17, img18, img19, img20, img21, img22, img23, img24);
            } else if (CardStyleActivity.flag == 2) {
                flipToCard2(imageViewcup, imageViewice, imageViewstr, imageViewcup2, imageViewice2, imageViewstr2, img7, img8, img9, img10, img11, img12, img13, img14, img15, img16, img17, img18, img19, img20, img21, img22, img23, img24);
            } else if (CardStyleActivity.flag == 3) {
                flipToCard3(imageViewcup, imageViewice, imageViewstr, imageViewcup2, imageViewice2, imageViewstr2, img7, img8, img9, img10, img11, img12, img13, img14, img15, img16, img17, img18, img19, img20, img21, img22, img23, img24);
            }

            // Set onClickListeners for each card
            setOnClickListener(imageViewcup, R.drawable.cupcake);
            setOnClickListener(imageViewcup2, R.drawable.cupcake);
            setOnClickListener(imageViewice, R.drawable.icecream);
            setOnClickListener(imageViewice2, R.drawable.icecream);
            setOnClickListener(imageViewstr, R.drawable.strwaberrycake);
            setOnClickListener(imageViewstr2, R.drawable.strwaberrycake);
            setOnClickListener(img7, R.drawable.cherry);
            setOnClickListener(img8, R.drawable.cherry);
            setOnClickListener(img9, R.drawable.apple);
            setOnClickListener(img10, R.drawable.apple);
            setOnClickListener(img11, R.drawable.birthdaycake);
            setOnClickListener(img12, R.drawable.birthdaycake);
            setOnClickListener(img13, R.drawable.avocado);
            setOnClickListener(img14, R.drawable.avocado);
            setOnClickListener(img15, R.drawable.donut);
            setOnClickListener(img16, R.drawable.donut);
            setOnClickListener(img17, R.drawable.pink_cake);
            setOnClickListener(img18, R.drawable.pink_cake);
            setOnClickListener(img19, R.drawable.berry);
            setOnClickListener(img20, R.drawable.berry);
            setOnClickListener(img21, R.drawable.choclate_cake);
            setOnClickListener(img22, R.drawable.choclate_cake);
            setOnClickListener(img23, R.drawable.birthday_cupcake);
            setOnClickListener(img24, R.drawable.birthday_cupcake);
        }, 10000); // Delay for initial display
    }

    private void flipToCard1(ImageView... images) {
        for (ImageView image : images) {
            image.setImageResource(R.drawable.card1);
        }
    }

    private void flipToCard2(ImageView... images) {
        for (ImageView image : images) {
            image.setImageResource(R.drawable.card2);
        }
    }

    private void flipToCard3(ImageView... images) {
        for (ImageView image : images) {
            image.setImageResource(R.drawable.card3);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        int performance = (int) (playerPerformanceTime / 1000);

        if (performance < 8) {
            level1Coins = 10;
        } else if (performance > 8) {
            level1Coins = 5;
        }
    }
}


