package com.doppelganger;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;

import com.doppelganger.R;

public class GameLevel1 extends GameBase {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_level_1);

        flipCards();
    }

    private void flipCards() {
        // Find image views
        Handler handler = new Handler(Looper.getMainLooper());
        ImageView imageViewcup =findViewById(R.id.cupcake);
        ImageView imageViewice =findViewById(R.id.icecream);
        ImageView imageViewstr =findViewById(R.id.strwaberrycake);
        ImageView imageViewcup2 =findViewById(R.id.cupcake2);
        ImageView imageViewice2 =findViewById(R.id.icecream2);
        ImageView imageViewstr2 =findViewById(R.id.strwaberrycake2);

        handler.postDelayed(() -> { // What code will run after the delay
            // Flip all cards back after showing initially
            imageViewcup.setImageResource(R.drawable.card);
            imageViewice.setImageResource(R.drawable.card);
            imageViewstr.setImageResource(R.drawable.card);
            imageViewcup2.setImageResource(R.drawable.card);
            imageViewice2.setImageResource(R.drawable.card);
            imageViewstr2.setImageResource(R.drawable.card);

            // Set onClickListeners for each card
            setOnClickListener(imageViewcup, R.drawable.cupcake);
            setOnClickListener(imageViewcup2, R.drawable.cupcake);
            setOnClickListener(imageViewice, R.drawable.icecream);
            setOnClickListener(imageViewice2, R.drawable.icecream);
            setOnClickListener(imageViewstr, R.drawable.strwaberrycake);
            setOnClickListener(imageViewstr2, R.drawable.strwaberrycake);
        }, 2000); // Delay for initial display
    }
}
