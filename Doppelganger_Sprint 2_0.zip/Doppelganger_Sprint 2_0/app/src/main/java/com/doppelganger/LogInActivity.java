package com.doppelganger;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;


import androidx.appcompat.app.AppCompatActivity;

import com.doppelganger.R;

public class LogInActivity extends AppCompatActivity {

    private EditText etEmail, etPassword;
    private Button btnLogIn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        // Initialize Views
        etEmail = findViewById(R.id.email_Login);
        etPassword = findViewById(R.id.password_Login);
        btnLogIn = findViewById(R.id.btnLogIn);

        // Handle login button click
        btnLogIn.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (email.isEmpty()) {
                etEmail.setError("Email is required");
                etEmail.requestFocus();
                return;
            }
            if (password.isEmpty()) {
                etPassword.setError("Password is required");
                etPassword.requestFocus();
                return;
            }
            // Perform login
            Intent intent = new Intent(LogInActivity.this, MainActivity.class);
            startActivity(intent);
        });


        }

        public void signUpButton(View view){
            Intent intent = new Intent(LogInActivity.this, SignUpActivity.class);
            startActivity(intent);
        }
    }


