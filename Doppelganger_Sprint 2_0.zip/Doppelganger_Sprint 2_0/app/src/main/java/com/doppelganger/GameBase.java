package com.doppelganger;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.doppelganger.R;

public abstract class GameBase extends AppCompatActivity {

    protected ImageView firstCard, secondCard;
    protected boolean isFirstCardFlipped = false;
    protected int mistakes = 0; // Track mistakes
    protected int matches = 0;  // Track matches
    protected int maxMistakes; // Max mistakes allowed
    protected int totalPairs;  // Total pairs of cards

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Get game settings from Intent
        maxMistakes = getIntent().getIntExtra("MAX_MISTAKES", 3);
        totalPairs = getIntent().getIntExtra("TOTAL_PAIRS", 3);
    }

    protected void setOnClickListener(final ImageView card, final int drawableId) {
        card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isFirstCardFlipped) {
                    firstCard = card;
                    card.setImageResource(drawableId);
                    isFirstCardFlipped = true;
                } else if (firstCard != card) {
                    secondCard = card;
                    card.setImageResource(drawableId);
                    isFirstCardFlipped = false;

                    if (firstCard.getDrawable().getConstantState().equals(secondCard.getDrawable().getConstantState())) {
                        firstCard.setEnabled(false);
                        secondCard.setEnabled(false);
                        matches++;
                        if (matches == totalPairs) {
                            showMessageAndEndGame("You won!");
                        }
                    } else {
                        mistakes++;
                        if (mistakes >= maxMistakes) {
                            showMessageAndEndGame("You lost! Too many mistakes.");
                        } else {
                            Handler handler = new Handler(Looper.getMainLooper());
                            handler.postDelayed(() -> {
                                firstCard.setImageResource(R.drawable.card);
                                secondCard.setImageResource(R.drawable.card);
                            }, 1000);
                        }
                    }
                }
            }
        });
    }

    protected void showMessageAndEndGame(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setCancelable(false)
                .setPositiveButton("OK", (dialog, id) -> {
                    Intent intent = new Intent(GameBase.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                });
        builder.create().show();
    }
}
