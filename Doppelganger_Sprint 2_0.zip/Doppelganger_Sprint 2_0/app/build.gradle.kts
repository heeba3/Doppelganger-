plugins {
    id("com.android.application") // Android plugin
    id("org.jetbrains.kotlin.android") version "1.9.0" // Updated to a compatible Kotlin version
    id("com.google.gms.google-services") version "4.3.15" // Updated Firebase Google Services plugin
}

android {
    namespace = "com.doppelganger"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.doppelganger"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false // Keep debugging friendly for now
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    // Ensure Java compatibility
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17" // Ensure Kotlin JVM target compatibility
    }

    // View Binding enabled for easier UI management
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    // Firebase dependencies
    implementation(platform("com.google.firebase:firebase-bom:32.2.0")) // BOM for Firebase libraries
    implementation("com.google.firebase:firebase-auth") // Firebase Authentication
    implementation("com.google.firebase:firebase-database") // Firebase Realtime Database

    // Core AndroidX dependencies
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // Material Design components
    implementation("com.google.android.material:material:1.9.0")

    // Testing dependencies
    testImplementation("junit:junit:4.13.2") // Unit testing
    androidTestImplementation("androidx.test.ext:junit:1.1.5") // Android test extensions
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1") // UI testing
}

apply(plugin = "com.google.gms.google-services") // Ensure Firebase plugin is applied
