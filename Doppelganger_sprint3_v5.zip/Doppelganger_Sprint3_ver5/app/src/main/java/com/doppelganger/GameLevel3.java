package com.doppelganger;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;

public class GameLevel3 extends GameBase {

    public int level3Coins = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_level_3);

        flipCards();
    }

    private void flipCards() {
        // Find image views
        Handler handler = new Handler(Looper.getMainLooper());
        ImageView imageViewcup = findViewById(R.id.cupcake);
        ImageView imageViewice = findViewById(R.id.icecream);
        ImageView imageViewstr = findViewById(R.id.strwaberrycake);
        ImageView imageViewcup2 = findViewById(R.id.cupcake2);
        ImageView imageViewice2 = findViewById(R.id.icecream2);
        ImageView imageViewstr2 = findViewById(R.id.strwaberrycake2);

        ImageView img7 = findViewById(R.id.cherry);
        ImageView img8 = findViewById(R.id.cherry2);
        ImageView img9 = findViewById(R.id.apple);
        ImageView img10 = findViewById(R.id.apple2);
        ImageView img11 = findViewById(R.id.birthdaycake);
        ImageView img12 = findViewById(R.id.birthdaycake2);

        ImageView img13 = findViewById(R.id.avocado);
        ImageView img14 = findViewById(R.id.avocado2);
        ImageView img15 = findViewById(R.id.donut);
        ImageView img16 = findViewById(R.id.donut2);
        ImageView img17 = findViewById(R.id.pink_cake);
        ImageView img18 = findViewById(R.id.pink_cake2);

        ImageView img19 = findViewById(R.id.berry);
        ImageView img20 = findViewById(R.id.berry2);
        ImageView img21 = findViewById(R.id.choclate_cake);
        ImageView img22 = findViewById(R.id.choclate_cake2);
        ImageView img23 = findViewById(R.id.birthday_cupcake);
        ImageView img24 = findViewById(R.id.birthday_cupcake2);

        handler.postDelayed(() -> {

            if(CardStyleActivity.flag==1){
                imageViewcup.setImageResource(R.drawable.card1);
                imageViewice.setImageResource(R.drawable.card1);
                imageViewstr.setImageResource(R.drawable.card1);
                imageViewcup2.setImageResource(R.drawable.card1);
                imageViewice2.setImageResource(R.drawable.card1);
                imageViewstr2.setImageResource(R.drawable.card1);
                img7.setImageResource(R.drawable.card1);
                img8.setImageResource(R.drawable.card1);
                img9.setImageResource(R.drawable.card1);
                img10.setImageResource(R.drawable.card1);
                img11.setImageResource(R.drawable.card1);
                img12.setImageResource(R.drawable.card1);
                img13.setImageResource(R.drawable.card1);
                img14.setImageResource(R.drawable.card1);
                img15.setImageResource(R.drawable.card1);
                img16.setImageResource(R.drawable.card1);
                img17.setImageResource(R.drawable.card1);
                img18.setImageResource(R.drawable.card1);
                img19.setImageResource(R.drawable.card1);
                img20.setImageResource(R.drawable.card1);
                img21.setImageResource(R.drawable.card1);
                img22.setImageResource(R.drawable.card1);
                img23.setImageResource(R.drawable.card1);
                img24.setImageResource(R.drawable.card1);
            }

            if(CardStyleActivity.flag==2){
                imageViewcup.setImageResource(R.drawable.card2);
                imageViewice.setImageResource(R.drawable.card2);
                imageViewstr.setImageResource(R.drawable.card2);
                imageViewcup2.setImageResource(R.drawable.card2);
                imageViewice2.setImageResource(R.drawable.card2);
                imageViewstr2.setImageResource(R.drawable.card2);
                img7.setImageResource(R.drawable.card2);
                img8.setImageResource(R.drawable.card2);
                img9.setImageResource(R.drawable.card2);
                img10.setImageResource(R.drawable.card2);
                img11.setImageResource(R.drawable.card2);
                img12.setImageResource(R.drawable.card2);
                img13.setImageResource(R.drawable.card2);
                img14.setImageResource(R.drawable.card2);
                img15.setImageResource(R.drawable.card2);
                img16.setImageResource(R.drawable.card2);
                img17.setImageResource(R.drawable.card2);
                img18.setImageResource(R.drawable.card2);
                img19.setImageResource(R.drawable.card2);
                img20.setImageResource(R.drawable.card2);
                img21.setImageResource(R.drawable.card2);
                img22.setImageResource(R.drawable.card2);
                img23.setImageResource(R.drawable.card2);
                img24.setImageResource(R.drawable.card2);
            }

            if(CardStyleActivity.flag==3){
                imageViewcup.setImageResource(R.drawable.card3);
                imageViewice.setImageResource(R.drawable.card3);
                imageViewstr.setImageResource(R.drawable.card3);
                imageViewcup2.setImageResource(R.drawable.card3);
                imageViewice2.setImageResource(R.drawable.card3);
                imageViewstr2.setImageResource(R.drawable.card3);
                img7.setImageResource(R.drawable.card3);
                img8.setImageResource(R.drawable.card3);
                img9.setImageResource(R.drawable.card3);
                img10.setImageResource(R.drawable.card3);
                img11.setImageResource(R.drawable.card3);
                img12.setImageResource(R.drawable.card3);
                img13.setImageResource(R.drawable.card3);
                img14.setImageResource(R.drawable.card3);
                img15.setImageResource(R.drawable.card3);
                img16.setImageResource(R.drawable.card3);
                img17.setImageResource(R.drawable.card3);
                img18.setImageResource(R.drawable.card3);
                img19.setImageResource(R.drawable.card3);
                img20.setImageResource(R.drawable.card3);
                img21.setImageResource(R.drawable.card3);
                img22.setImageResource(R.drawable.card3);
                img23.setImageResource(R.drawable.card3);
                img24.setImageResource(R.drawable.card3);
            }
            else{
                imageViewcup.setImageResource(R.drawable.card2);
                imageViewice.setImageResource(R.drawable.card2);
                imageViewstr.setImageResource(R.drawable.card2);
                imageViewcup2.setImageResource(R.drawable.card2);
                imageViewice2.setImageResource(R.drawable.card2);
                imageViewstr2.setImageResource(R.drawable.card2);
                img7.setImageResource(R.drawable.card2);
                img8.setImageResource(R.drawable.card2);
                img9.setImageResource(R.drawable.card2);
                img10.setImageResource(R.drawable.card2);
                img11.setImageResource(R.drawable.card2);
                img12.setImageResource(R.drawable.card2);
                img13.setImageResource(R.drawable.card2);
                img14.setImageResource(R.drawable.card2);
                img15.setImageResource(R.drawable.card2);
                img16.setImageResource(R.drawable.card2);
                img17.setImageResource(R.drawable.card2);
                img18.setImageResource(R.drawable.card2);
                img19.setImageResource(R.drawable.card2);
                img20.setImageResource(R.drawable.card2);
                img21.setImageResource(R.drawable.card2);
                img22.setImageResource(R.drawable.card2);
                img23.setImageResource(R.drawable.card2);
                img24.setImageResource(R.drawable.card2);
            }


            // Set onClickListeners for each card
            setOnClickListener(imageViewcup, R.drawable.cupcake);
            setOnClickListener(imageViewcup2, R.drawable.cupcake);
            setOnClickListener(imageViewice, R.drawable.icecream);
            setOnClickListener(imageViewice2, R.drawable.icecream);
            setOnClickListener(imageViewstr, R.drawable.strwaberrycake);
            setOnClickListener(imageViewstr2, R.drawable.strwaberrycake);
            setOnClickListener(img7, R.drawable.cherry);
            setOnClickListener(img8, R.drawable.cherry);
            setOnClickListener(img9, R.drawable.apple);
            setOnClickListener(img10, R.drawable.apple);
            setOnClickListener(img11, R.drawable.birthdaycake);
            setOnClickListener(img12, R.drawable.birthdaycake);
            setOnClickListener(img13, R.drawable.avocado);
            setOnClickListener(img14, R.drawable.avocado);
            setOnClickListener(img15, R.drawable.donut);
            setOnClickListener(img16, R.drawable.donut);
            setOnClickListener(img17, R.drawable.pink_cake);
            setOnClickListener(img18, R.drawable.pink_cake);
            setOnClickListener(img19, R.drawable.berry);
            setOnClickListener(img20, R.drawable.berry);
            setOnClickListener(img21, R.drawable.choclate_cake);
            setOnClickListener(img22, R.drawable.choclate_cake);
            setOnClickListener(img23, R.drawable.birthday_cupcake);
            setOnClickListener(img24, R.drawable.birthday_cupcake);
        }, 10000); // Delay for initial display
    }

    @Override
    protected void onStop() {
        super.onStop();
        int performance = (int) (playerPerformanceTime / 1000);

        if (performance < 30) {
            level3Coins = 10;
        } else if (performance > 30) {
            level3Coins = 5;
        }
    }
}
