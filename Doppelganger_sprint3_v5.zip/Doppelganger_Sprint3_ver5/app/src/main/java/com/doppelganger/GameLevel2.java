package com.doppelganger;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;

import com.doppelganger.R;

public class GameLevel2 extends GameBase {

    public int level2Coins=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_level_2);


        flipCards();
    }

    private void flipCards() {
        // Find image views
        Handler handler = new Handler(Looper.getMainLooper());
        ImageView imageViewcup =findViewById(R.id.cupcake);
        ImageView imageViewice =findViewById(R.id.icecream);
        ImageView imageViewstr =findViewById(R.id.strwaberrycake);
        ImageView imageViewapple =findViewById(R.id.apple);
        ImageView imageViewavocado =findViewById(R.id.avocado);
        ImageView imageViewcherry =findViewById(R.id.cherry);
        ImageView imageViewapple2 =findViewById(R.id.apple2);
        ImageView imageViewavocado2 =findViewById(R.id.avocado2);
        ImageView imageViewcherry2 =findViewById(R.id.cherry2);
        ImageView imageViewcup2 =findViewById(R.id.cupcake2);
        ImageView imageViewice2 =findViewById(R.id.icecream2);
        ImageView imageViewstr2 =findViewById(R.id.strwaberrycake2);

        handler.postDelayed(() -> { // What code will run after the delay
            // Flip all cards back after showing initially

            if(CardStyleActivity.flag==1){
                imageViewcup.setImageResource(R.drawable.card1);
                imageViewice.setImageResource(R.drawable.card1);
                imageViewstr.setImageResource(R.drawable.card1);
                imageViewcup2.setImageResource(R.drawable.card1);
                imageViewice2.setImageResource(R.drawable.card1);
                imageViewstr2.setImageResource(R.drawable.card1);
                imageViewavocado.setImageResource(R.drawable.card1);
                imageViewapple.setImageResource(R.drawable.card1);
                imageViewcherry.setImageResource(R.drawable.card1);
                imageViewavocado2.setImageResource(R.drawable.card1);
                imageViewapple2.setImageResource(R.drawable.card1);
                imageViewcherry2.setImageResource(R.drawable.card1);
            }
            if(CardStyleActivity.flag==2){
                imageViewcup.setImageResource(R.drawable.card2);
                imageViewice.setImageResource(R.drawable.card2);
                imageViewstr.setImageResource(R.drawable.card2);
                imageViewcup2.setImageResource(R.drawable.card2);
                imageViewice2.setImageResource(R.drawable.card2);
                imageViewstr2.setImageResource(R.drawable.card2);
                imageViewavocado.setImageResource(R.drawable.card2);
                imageViewapple.setImageResource(R.drawable.card2);
                imageViewcherry.setImageResource(R.drawable.card2);
                imageViewavocado2.setImageResource(R.drawable.card2);
                imageViewapple2.setImageResource(R.drawable.card2);
                imageViewcherry2.setImageResource(R.drawable.card2);
            }
            if(CardStyleActivity.flag==3){
                imageViewcup.setImageResource(R.drawable.card3);
                imageViewice.setImageResource(R.drawable.card3);
                imageViewstr.setImageResource(R.drawable.card3);
                imageViewcup2.setImageResource(R.drawable.card3);
                imageViewice2.setImageResource(R.drawable.card3);
                imageViewstr2.setImageResource(R.drawable.card3);
                imageViewavocado.setImageResource(R.drawable.card3);
                imageViewapple.setImageResource(R.drawable.card3);
                imageViewcherry.setImageResource(R.drawable.card3);
                imageViewavocado2.setImageResource(R.drawable.card3);
                imageViewapple2.setImageResource(R.drawable.card3);
                imageViewcherry2.setImageResource(R.drawable.card3);
            }
            else{
                imageViewcup.setImageResource(R.drawable.card2);
                imageViewice.setImageResource(R.drawable.card2);
                imageViewstr.setImageResource(R.drawable.card2);
                imageViewcup2.setImageResource(R.drawable.card2);
                imageViewice2.setImageResource(R.drawable.card2);
                imageViewstr2.setImageResource(R.drawable.card2);
                imageViewavocado.setImageResource(R.drawable.card2);
                imageViewapple.setImageResource(R.drawable.card2);
                imageViewcherry.setImageResource(R.drawable.card2);
                imageViewavocado2.setImageResource(R.drawable.card2);
                imageViewapple2.setImageResource(R.drawable.card2);
                imageViewcherry2.setImageResource(R.drawable.card2);
            }


            // Set onClickListeners for each card
            setOnClickListener(imageViewcup, R.drawable.cupcake);
            setOnClickListener(imageViewcup2, R.drawable.cupcake);
            setOnClickListener(imageViewice, R.drawable.icecream);
            setOnClickListener(imageViewice2, R.drawable.icecream);
            setOnClickListener(imageViewstr, R.drawable.strwaberrycake);
            setOnClickListener(imageViewstr2, R.drawable.strwaberrycake);
            setOnClickListener(imageViewavocado, R.drawable.avocado);
            setOnClickListener(imageViewavocado2, R.drawable.avocado);
            setOnClickListener(imageViewcherry, R.drawable.cherry);
            setOnClickListener(imageViewcherry2, R.drawable.cherry);
            setOnClickListener(imageViewapple, R.drawable.apple);
            setOnClickListener(imageViewapple2, R.drawable.apple);
        }, 4000); // Delay for initial display
    }

    protected void onStop(){
        super.onStop();
        int performance= (int) (playerPerformanceTime / 1000);

        if(performance < 15){
            level2Coins=10;
        } else if (performance > 15) {
            level2Coins=5;
        }
    }
}
