package com.doppelganger;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import com.doppelganger.R;

public class LevelSelection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.levelselection);

        // Button for Level 1
        Button level1Button = findViewById(R.id.level1Button);
        level1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start GameLevel1 Activity
                Intent intent = new Intent(LevelSelection.this, GameLevel1.class);
                intent.putExtra("MAX_MISTAKES", 3);
                intent.putExtra("TOTAL_PAIRS", 3);
                startActivity(intent);
            }
        });

        // Button for Level 2
        Button level2Button = findViewById(R.id.level2Button);
        level2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start GameLevel2 Activity
                Intent intent = new Intent(LevelSelection.this, GameLevel2.class);
                intent.putExtra("MAX_MISTAKES", 4);
                intent.putExtra("TOTAL_PAIRS", 6);
                startActivity(intent);
            }
        });


        // Button for Level 3
        Button level3Button = findViewById(R.id.level3Button);
        level3Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start GameLevel1 Activity
                Intent intent = new Intent(LevelSelection.this, GameLevel3.class);
                intent.putExtra("MAX_MISTAKES", 9);
                intent.putExtra("TOTAL_PAIRS", 12);
                startActivity(intent);
            }
        });


    }
}

