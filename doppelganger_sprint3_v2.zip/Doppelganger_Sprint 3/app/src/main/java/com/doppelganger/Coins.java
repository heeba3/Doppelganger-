package com.doppelganger;

public class Coins {
    private int coins;
    GameLevel1 level1= new GameLevel1();
    GameLevel2 level2= new GameLevel2();

    public int calcCoins(){

        coins= level1.level1Coins+level2.level2Coins;
        return coins;

    }
}
